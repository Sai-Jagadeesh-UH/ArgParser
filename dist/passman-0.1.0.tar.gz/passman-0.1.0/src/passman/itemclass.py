from dataclasses import dataclass


@dataclass
class Item:
    id: str
    password: str
